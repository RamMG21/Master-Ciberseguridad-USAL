---
tipo: noticia
titular: "Scotland | Glasgow and West | Maddy father named as 'suspect'"
medio: "BBC"
fecha: 2007-09-08
url: "http://news.bbc.co.uk/2/hi/uk_news/scotland/glasgow_and_west/6984689.stm"
url_google: "https://news.google.com/rss/articles/CBMifEFVX3lxTFBzbzgzSVFOald6ejE4eUhQNWZ1eDIwVXFERmQ1SmVrV0gzRS0ydnNGeXlTTFkwdDMtTjRlUHRTdGNrVHVDOXdhbUJqUENQbThuc1YydTY3dDAtaEZLNVZOalRGLWpFNU5aX2VkZjBLcXNuV2ptNEJLMkVUWUE?oc=5"
edicion: "Reino Unido"
ventana: "2007-09"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2007-09-01 before:2007-10-01"
puntos: 1
motivo: "+ suspect"
capturado: "2026-09-25T14:57:27"
tags: [noticia, mccann]
---

# Scotland | Glasgow and West | Maddy father named as 'suspect'

> Texto del artículo pendiente de extraer con defuddle.
