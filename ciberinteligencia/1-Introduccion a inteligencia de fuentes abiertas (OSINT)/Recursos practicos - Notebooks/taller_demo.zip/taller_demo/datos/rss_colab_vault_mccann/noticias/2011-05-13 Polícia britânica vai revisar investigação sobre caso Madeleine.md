---
tipo: noticia
titular: "Polícia britânica vai revisar investigação sobre caso Madeleine"
medio: "BBC"
fecha: 2011-05-13
url: "https://www.bbc.com/portuguese/noticias/2011/05/110513_scotlandyard_madeleine_revisao_cc"
url_google: "https://news.google.com/rss/articles/CBMikgFBVV95cUxPa0UwUkdfdGdROEZrbmFVWXNaeVFYSUNRNjBjZnlIYmpUS0xtbjdYWEthVklmdkJHY2c5b3VtXzc4RXNYYWZETk5sTWtHZGs0M3FmTHdPRWlScFl4TV94bnhEMGhBc2tfWE1LRkV4MVNBMndvZU5QbzlJYWlWR2tHU3lGM1NxcklxaGFVN1lDV2ZsUQ?oc=5"
edicion: "Portugal"
ventana: "2011"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2011-01-01 before:2012-01-01"
puntos: 2
motivo: "+ polícia, investigação"
capturado: "2026-09-25T14:58:42"
tags: [noticia, mccann]
---

# Polícia britânica vai revisar investigação sobre caso Madeleine

> Texto del artículo pendiente de extraer con defuddle.
