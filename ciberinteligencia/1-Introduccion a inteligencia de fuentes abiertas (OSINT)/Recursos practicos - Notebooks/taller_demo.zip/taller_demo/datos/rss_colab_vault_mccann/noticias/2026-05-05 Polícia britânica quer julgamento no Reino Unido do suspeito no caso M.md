---
tipo: noticia
titular: "Polícia britânica quer julgamento no Reino Unido do suspeito no caso Maddie e pretende a extradição de Brueckner"
medio: "Observador"
fecha: 2026-05-05
url: "https://observador.pt/2026/05/05/policia-britanica-quer-julgamento-no-reino-unido-do-suspeito-no-caso-maddie-e-pretende-a-extradicao-de-brueckner/"
url_google: "https://news.google.com/rss/articles/CBMi3wFBVV95cUxORnNxY2wzdkdtVkxXLVNRVHNIRVBPa0ZfYWc1Q0VZdTNjeWVsQUUyYWNXa25VTDJMZmduVEtJWnhOX0x3ZDhhOXVqOUw2c2xHQzJlaHRCeE9vbS1zS0F5VmJYSkJhNEVCQnY1cW01S3dsX2NHMlc1MkRNTG9JSV9TRDNKaERTOFpza09pR1M0NC0zeVNqaVRoaWh1SDJMS2w0d1JrRTBrb0Q0VmxONVY1MjZrS3hsRkxHT0xnUDhXUEdZSTE5X0EyeEtiQXQ1WGFwS212TXRLcGpINDBrNVRF?oc=5"
edicion: "Portugal"
ventana: "2026"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2026-01-01 before:2026-09-25"
puntos: 4
motivo: "+ polícia, suspeito, julgamento, brueckner"
capturado: "2026-09-25T15:00:50"
tags: [noticia, mccann]
---

# Polícia britânica quer julgamento no Reino Unido do suspeito no caso Maddie e pretende a extradição de Brueckner

> Texto del artículo pendiente de extraer con defuddle.
