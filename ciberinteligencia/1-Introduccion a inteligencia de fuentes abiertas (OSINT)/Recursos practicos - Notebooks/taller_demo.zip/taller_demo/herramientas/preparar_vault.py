#!/usr/bin/env python3
"""
preparar_vault.py · Taller de Obsidian (Ciberinteligencia, USAL)
----------------------------------------------------------------------
Monta el vault del taller a partir de las dos fuentes de datos:

  1) Las notas del notebook 05B (RSS de Google News): carpeta vault_mccann/
     (descomprimida de vault_mccann.zip). Traen propiedades, pero no el texto.
  2) Los .txt del script osint_news_scraper.py (DuckDuckGo): carpeta
     noticias_mccann_osint/. Traen el texto, pero no fecha ni medio.

Qué hace:
  - Copia las notas RSS a <salida>/noticias/ y les añade `origen: rss`.
  - Convierte cada .txt de DuckDuckGo en una nota .md con propiedades
    (`origen: duckduckgo`) y descarta las que ya estaban en el RSS (misma URL).
  - Con --defuddle, descarga el texto de cada noticia RSS con la CLI de
    Defuddle (npm install -g defuddle) y lo pega en la nota.
  - Crea las carpetas de entidades, copia CLAUDE_vault.md como CLAUDE.md
    y, con --skills, copia las skills de kepano a <salida>/.claude/skills/.
  - Escribe _informe_preparacion.md con lo que ha fallado.

Solo usa la biblioteca estándar de Python (3.9+).

Uso típico:
  python3 preparar_vault.py --rss vault_mccann --ddg noticias_mccann_osint \
      --salida vault_taller --defuddle --skills obsidian-skills/skills
----------------------------------------------------------------------
"""
import argparse
import json
import re
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlparse

MARCA_PENDIENTE = "> Texto del artículo pendiente de extraer con defuddle."
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
      "(KHTML, like Gecko) Version/17.0 Safari/605.1.15")
MIN_TEXTO = 300  # caracteres: menos que esto suele ser un muro de cookies o de pago
AQUI = Path(__file__).resolve().parent


# ---------------------------------------------------------------- utilidades
def leer_prop(texto, clave):
    m = re.search(rf"^{clave}:\s*(.*)$", texto.split("\n---", 1)[0], flags=re.M)
    if not m:
        return ""
    return m.group(1).strip().strip('"')


def poner_prop(texto, clave, valor):
    """Añade o sustituye una propiedad en el frontmatter (primer bloque ---)."""
    if not texto.startswith("---\n"):
        return f"---\n{clave}: {valor}\n---\n\n" + texto
    fin = texto.index("\n---", 4)
    cabecera, resto = texto[:fin], texto[fin:]
    if re.search(rf"^{clave}:", cabecera, flags=re.M):
        cabecera = re.sub(rf"^{clave}:.*$", f"{clave}: {valor}", cabecera, flags=re.M)
    else:
        cabecera += f"\n{clave}: {valor}"
    return cabecera + resto


def comillas(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def nombre_seguro(s, max_len=70):
    s = re.sub(r'[\\/:*?"<>|#^\[\]]', "", s)
    return re.sub(r"\s+", " ", s).strip()[:max_len].rstrip() or "sin titulo"


def fecha_de_url(url):
    m = re.search(r"/(20\d\d|19\d\d)[/-](\d{1,2})[/-](\d{1,2})/", url)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    return ""


def normalizar_url(url):
    u = urlparse(url.strip())
    return (u.netloc.lower().removeprefix("www.") + u.path.rstrip("/")).lower()


# ---------------------------------------------------------------- pasos
def copiar_rss(origen, destino):
    carpeta = origen / "noticias" if (origen / "noticias").is_dir() else origen
    notas = sorted(carpeta.glob("*.md"))
    urls = set()
    for nota in notas:
        texto = nota.read_text(encoding="utf-8")
        texto = poner_prop(texto, "origen", "rss")
        if MARCA_PENDIENTE in texto:
            texto = poner_prop(texto, "texto", "pendiente")
        (destino / nota.name).write_text(texto, encoding="utf-8")
        url = leer_prop(texto, "url")
        if url:
            urls.add(normalizar_url(url))
    return len(notas), urls


def convertir_ddg(origen, destino, urls_rss):
    creadas, repetidas = 0, 0
    for txt in sorted(origen.glob("*.txt")):
        crudo = txt.read_text(encoding="utf-8", errors="replace")
        lineas = crudo.split("\n")
        titulo = lineas[0].lstrip("# ").strip() if lineas else txt.stem
        m = re.search(r"^URL:\s*(\S+)", crudo, flags=re.M)
        url = m.group(1) if m else ""
        if url and normalizar_url(url) in urls_rss:
            repetidas += 1
            continue
        cuerpo = crudo.split(m.group(0), 1)[1].strip() if m else "\n".join(lineas[1:]).strip()
        # Las versiones nuevas del script escriben también "Fecha:" y "Medio:" tras la URL
        mf = re.match(r"Fecha:[ \t]*(\S*)[ \t]*\n", cuerpo)
        fecha = (mf.group(1) if mf else "") or fecha_de_url(url)
        cuerpo = cuerpo[mf.end():] if mf else cuerpo
        mm = re.match(r"Medio:[ \t]*(.*)\n", cuerpo)
        medio = (mm.group(1).strip() if mm else "") or (urlparse(url).netloc.removeprefix("www.") if url else "")
        cuerpo = cuerpo[mm.end():].strip() if mm else cuerpo
        nota = "\n".join([
            "---",
            "tipo: noticia",
            f"titular: {comillas(titulo)}",
            f"medio: {comillas(medio)}",
            f"fecha: {fecha}" if fecha else 'fecha: ""',
            f"url: {comillas(url)}",
            "origen: duckduckgo",
            "texto: script",
            "tags: [noticia, mccann]",
            "---",
            "",
            f"# {titulo}",
            "",
            "## Texto",
            "",
            cuerpo,
            "",
        ])
        prefijo = fecha or "sin-fecha"
        (destino / f"{prefijo} {nombre_seguro(titulo)}.md").write_text(nota, encoding="utf-8")
        creadas += 1
    return creadas, repetidas


def defuddle_una(nota):
    texto = nota.read_text(encoding="utf-8")
    url = leer_prop(texto, "url")
    if MARCA_PENDIENTE not in texto or not url:
        return nota.name, "sin url" if not url else "ya tenía texto"
    error = ""
    try:
        # shutil.which encuentra también defuddle.cmd en Windows
        r = subprocess.run([shutil.which("defuddle") or "defuddle", "parse", url, "--md", "--user-agent", UA],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90)
        salida, error = r.stdout.strip(), r.stderr.strip()
        ok = r.returncode == 0 and len(salida) >= MIN_TEXTO
    except (subprocess.TimeoutExpired, OSError) as e:
        ok, salida, error = False, "", type(e).__name__
    if ok:
        texto = texto.replace(MARCA_PENDIENTE, "## Texto\n\n" + salida)
        texto = poner_prop(texto, "texto", "defuddle")
        estado = "ok"
    else:
        texto = poner_prop(texto, "texto", "fallo")
        estado = "fallo: " + (error[:120] or f"texto demasiado corto ({len(salida)} caracteres)")
    nota.write_text(texto, encoding="utf-8")
    return nota.name, estado


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rss", type=Path, help="carpeta vault_mccann del notebook 05B")
    ap.add_argument("--ddg", type=Path, help="carpeta noticias_mccann_osint del script de DuckDuckGo")
    ap.add_argument("--salida", type=Path, default=Path("vault_taller"))
    ap.add_argument("--defuddle", action="store_true", help="descargar el texto de las noticias RSS")
    ap.add_argument("--hilos", type=int, default=4)
    ap.add_argument("--skills", type=Path, help="carpeta skills/ del repositorio kepano/obsidian-skills")
    ap.add_argument("--forzar", action="store_true", help="escribir aunque el vault de salida ya tenga noticias")
    a = ap.parse_args()

    # Comprobar las rutas ANTES de hacer nada (y sugerir la buena si hay una parecida)
    errores = []
    for opcion, ruta in (("--rss", a.rss), ("--ddg", a.ddg), ("--skills", a.skills)):
        if ruta and not ruta.is_dir():
            parecidas = [str(p) for p in Path(".").glob("**/" + ruta.name) if p.is_dir()][:3]
            pista = f"  ¿Querías decir {' o '.join(parecidas)}?" if parecidas else ""
            errores.append(f"[!] {opcion} {ruta}: no existe.{pista}")
    if errores:
        print("\n".join(errores))
        print("    No he tocado nada. Ejecuta el script desde la carpeta del taller y revisa las rutas.")
        return

    noticias = a.salida / "noticias"
    if noticias.is_dir() and any(noticias.glob("*.md")) and not a.forzar:
        print(f"[!] {noticias} ya tiene noticias. No toco nada para no pisar tu trabajo.")
        print("    Usa otra carpeta con --salida, o añade --forzar si de verdad quieres sobrescribir.")
        return
    noticias.mkdir(parents=True, exist_ok=True)
    for sub in ["personas", "lugares", "organizaciones", "eventos"]:
        (a.salida / "entidades" / sub).mkdir(parents=True, exist_ok=True)

    informe = [f"# Informe de preparación · {time.strftime('%Y-%m-%d %H:%M')}", ""]

    urls_rss = set()
    if a.rss:
        n, urls_rss = copiar_rss(a.rss, noticias)
        print(f"[RSS] {n} notas copiadas")
        informe.append(f"- RSS: {n} notas")
    if a.ddg:
        n, rep = convertir_ddg(a.ddg, noticias, urls_rss)
        print(f"[DDG] {n} notas creadas, {rep} descartadas por estar ya en el RSS")
        informe.append(f"- DuckDuckGo: {n} notas nuevas, {rep} repetidas con el RSS")

    if a.defuddle:
        if not shutil.which("defuddle"):
            print("[!] No encuentro la CLI de defuddle. Instálala con: npm install -g defuddle")
        else:
            pendientes = [p for p in sorted(noticias.glob("*.md"))
                          if MARCA_PENDIENTE in p.read_text(encoding="utf-8")]
            print(f"[defuddle] {len(pendientes)} noticias por descargar con {a.hilos} hilos…")
            with ThreadPoolExecutor(max_workers=a.hilos) as ex:
                resultados = list(ex.map(defuddle_una, pendientes))
            buenos = sum(e == "ok" for _, e in resultados)
            print(f"[defuddle] {buenos}/{len(resultados)} con texto")
            informe += ["", f"## Defuddle: {buenos}/{len(resultados)} con texto", ""]
            informe += [f"- `{n}`: {e}" for n, e in resultados if e != "ok"]

    claude_md = AQUI / "CLAUDE_vault.md"
    if claude_md.exists():
        shutil.copy(claude_md, a.salida / "CLAUDE.md")
    if a.skills:
        destino = a.salida / ".claude" / "skills"
        shutil.copytree(a.skills, destino, dirs_exist_ok=True)
        print(f"[skills] copiadas en {destino}")

    # Ajustes del grafo: un color por tipo de entidad y flechas (solo si el vault aún no los tiene)
    grafo = a.salida / ".obsidian" / "graph.json"
    if not grafo.exists():
        grafo.parent.mkdir(exist_ok=True)
        grafo.write_text(json.dumps({
            "search": "", "showTags": False, "showAttachments": False, "hideUnresolved": False,
            "showOrphans": True, "showArrow": True, "textFadeMultiplier": 0,
            "nodeSizeMultiplier": 1, "lineSizeMultiplier": 1, "repelStrength": 12,
            "linkDistance": 250, "linkStrength": 1, "centerStrength": 0.5,
            "colorGroups": [
                {"query": "path:entidades/personas", "color": {"a": 1, "rgb": 3900150}},
                {"query": "path:entidades/lugares", "color": {"a": 1, "rgb": 2278750}},
                {"query": "path:entidades/organizaciones", "color": {"a": 1, "rgb": 16096779}},
                {"query": "path:entidades/eventos", "color": {"a": 1, "rgb": 15680580}},
            ]}, indent=2), encoding="utf-8")

    (a.salida / "_informe_preparacion.md").write_text("\n".join(informe) + "\n", encoding="utf-8")
    total = len(list(noticias.glob("*.md")))
    print(f"\nVault listo en {a.salida}/ con {total} noticias. Ábrelo en Obsidian como bóveda.")


if __name__ == "__main__":
    main()
