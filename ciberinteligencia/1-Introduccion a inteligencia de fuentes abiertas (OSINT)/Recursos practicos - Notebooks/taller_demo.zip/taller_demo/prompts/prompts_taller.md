# Prompts del taller · para copiar y pegar

Todos se usan con el agente de IA **arrancado dentro de `vault_demo/`** (paso 9 de la guía). Cada uno, en el paso que se indica.

## Paso 9 · Comprobar que el agente ve las reglas y las skills
```
Ejecuta pwd y dime en qué carpeta estás. Después: ¿qué skills tienes disponibles y qué reglas hay en CLAUDE.md? Responde en una lista corta.
```

## Paso 10 · Procesar las 10 noticias (prompt único)
```
Lee CLAUDE.md y usa la skill obsidian-markdown. Procesa TODAS las noticias de noticias/ (son 10):

1. Para cada noticia, extrae las personas, lugares, organizaciones y eventos relevantes y crea o actualiza su nota en entidades/ siguiendo exactamente la plantilla y las reglas de CLAUDE.md. Antes de crear una entidad, comprueba si ya existe (también por alias).
2. En cada evento, indica en "## Relaciones" quién lo ejecutó o protagonizó, si la noticia lo dice (regla 5b).
3. Añade al final de cada noticia la sección "## Entidades" con los enlaces, agrupados por tipo.
4. Crea "MOC - Caso McCann.md", el mapa de contenido del vault: un párrafo de contexto (con sus fuentes) y las secciones Personas, Lugares, Organizaciones, Eventos (por fecha) y Contradicciones.

Al terminar, dame: una tabla de entidades por tipo con su número de fuentes, las contradicciones que hayas encontrado y las decisiones que hayas tomado por prudencia.
```

## Paso 11 · Revisar lo que ha hecho la IA
```
Revisa las notas de entidades/ y dame una lista de: (1) frases sin enlace a una noticia; (2) enlaces a notas que no existen; (3) afirmaciones sobre culpabilidad que no estén literalmente en la fuente. No corrijas nada todavía.
```
Después, a mano: abre dos entidades, elige una frase de cada una y comprueba en la noticia citada que dice eso.

## Paso 12 · Filtro del grafo (en Obsidian, no en la IA)
Vista de grafo → ajustes → Filtros → Buscar archivos:
```
path:entidades -path:"entidades/eventos/Desaparición de Madeleine McCann.md"
```

## Paso 13 · Mapa de vínculos (Canvas)
Cambia `PERSONA CENTRAL` y el nombre del fichero para otra persona (por ejemplo, Robert Murat).
```
Lee CLAUDE.md y usa la skill json-canvas. Crea un MAPA DE VÍNCULOS (link chart) centrado en una persona.

PERSONA CENTRAL: Christian Brueckner

DATOS: solo las secciones "## Relaciones" de entidades/. No leas noticias ni uses lo que sepas del caso.

QUÉ ENTIDADES ENTRAN:
- Nivel 1: toda entidad que aparezca en una relación de la persona central, o que tenga una relación hacia ella.
- Nivel 2: las personas y organizaciones que tengan relación con los EVENTOS del nivel 1. No añadas lugares ni eventos de nivel 2.
- Excluye las noticias y el evento genérico "Desaparición de Madeleine McCann". Máximo 30 nodos.

REGLAS DE LAS FLECHAS:
1. El destino de cada flecha es EXACTAMENTE la entidad enlazada en esa línea de Relaciones. Si no está en el mapa, añádela; nunca la redirijas a otra parecida.
2. Una sola flecha por par de entidades; si hay varias relaciones, júntalas en una etiqueta.
3. Los eventos no son actores: la flecha va de quien actúa al evento o a la persona afectada.
4. Gris "#9ca3af" y "(?)" SOLO si es una afirmación de parte (el propio implicado, su entorno o su abogado) o tiene un aviso de contradicción. Lo que la fuente da como hecho, en negro.
5. Etiqueta de 2 a 5 palabras, en español, con el año si la relación cambió con el tiempo.

NODOS: cada entidad es un nodo de tipo "file" que apunta a su nota. Colores: personas "#3b82f6", organizaciones "#f59e0b", lugares "#22c55e", eventos "#ef4444", persona central "#8b5cf6". Persona central en el centro; personas arriba, organizaciones a la derecha, lugares abajo, eventos a la izquierda ordenados por fecha. Al menos 120 px entre nodos. Añade un grupo "Leyenda".

Guarda el resultado como "mapas/Mapa de vínculos - Christian Brueckner.canvas".
Al terminar: tabla origen → etiqueta → destino → nota de la que sale, y la lista de flechas grises con su motivo.
```
