# Del titular al mapa · Taller de Obsidian paso a paso

**Máster Universitario en Ciberseguridad · Ciberinteligencia · Taller OSINT**

En este taller convertimos un montón de noticias sobre un caso real, la desaparición de Madeleine McCann (Portugal, 2007), en una **red de personas, lugares, organizaciones y eventos** que se puede consultar en Obsidian. Una IA hace el trabajo pesado; nosotros decidimos las reglas y **comprobamos que no se invente nada**.

Esta guía sirve **en clase** (el profesor lo hace en pantalla y tú puedes seguirlo) y **en casa** (para repetirlo a tu ritmo). En clase trabajamos con **10 noticias**, por tiempo: el proceso es el mismo que con el caso completo. En la parte 7 tienes cómo hacerlo a escala real con este mismo kit.

```
 RECOGER            LIMPIAR           MONTAR               IA                  VER
 RSS (Colab)   ──►  apartar lo   ──►  skills + defuddle ─► entidades y   ──►  grafo, mapa
 buscador           que no es         + preparar_vault     relaciones          de vínculos
 (script)           noticia                                                    y preguntas
 Parte 2            Paso 4            Parte 3              Parte 4             Partes 5 y 6
```

> **Uso responsable.** Son personas reales, algunas investigadas y nunca condenadas por el caso. Lo que construyas es un ejercicio de la asignatura: **no lo publiques ni lo compartas**. Que algo esté publicado no hace inocuo reunirlo en fichas.

---

## Cómo leer esta guía

Los prompts de la Parte 4 y 5 están también en `prompts/prompts_taller.md`.

Cada paso tiene la misma forma:

- **Qué haces:** en una línea.
- **Por qué:** el sentido del paso dentro del proceso.
- **Copia y pega:** los comandos. Si cambian según el sistema, hay un bloque para macOS/Linux y otro para Windows.
- **Deberías ver:** cómo saber que ha ido bien.
- **Si te has perdido:** un **punto de control**, un zip con el resultado del paso, para seguir desde ahí sin repetir nada.

| En clase, cuando el profesor diga… | Ve a… |
|---|---|
| **DEMO 1 · Obsidian** | Parte 1 (y el documento `demo1_familia.md`) |
| **DEMO 2 · Recoger los datos** | Parte 2 (pasos 2 a 4) |
| **DEMO 3 · Montar el vault y la IA** | Partes 3 y 4 (pasos 5 a 11) |
| **ANÁLISIS** | Partes 5 y 6 (pasos 12 y 13, y ejercicios) |

---

## Parte 0 · Antes de empezar

### 0.1 · Qué necesitas

| Qué | Para qué | Enlace | ¿Imprescindible? |
|---|---|---|---|
| **Obsidian** | Ver y analizar el vault | https://obsidian.md | Sí |
| **Cuenta de Google** | Ejecutar el notebook en Colab | https://colab.research.google.com | Para la Parte 2 |
| **Python 3.9 o superior** | Los scripts | https://www.python.org/downloads/ (en Windows, marca **«Add Python to PATH»**) | Sí |
| **Node.js 20 o superior** | La herramienta defuddle | https://nodejs.org | Recomendado |
| **Git** | Descargar las skills | https://git-scm.com | Recomendado (hay plan B) |
| **Un agente de IA con acceso a ficheros** | Extraer entidades | Ver paso 9 | Para la Parte 4 |

Comprueba lo que tienes en una terminal:

```bash
python3 --version     # en Windows: python --version
node --version
git --version
```

> En esta guía, **`python3`** es el comando de macOS y Linux. En Windows usa **`python`** (o `py`).

### 0.2 · El kit del taller

Descarga **`taller_demo.zip`** de Moodle y descomprímelo donde quieras (por ejemplo, en el Escritorio). Dentro verás esto:

```
taller_demo/
├── guia_taller_paso_a_paso.md             esta guía
├── demo1_familia.md                       la demo 1
├── herramientas/
│   ├── 05B_rss_python_caso_mccann.ipynb   notebook de Colab: noticias por RSS
│   ├── osint_news_scraper.py              script: noticias con un buscador
│   ├── separar_no_noticias.py             script: aparta lo que no es noticia
│   ├── preparar_vault.py                  script: monta el vault
│   ├── CLAUDE_vault.md                    las reglas que seguirá la IA
│   └── obsidian-skills/                   las skills de kepano (ya descargadas, por si falla Git)
├── datos/
│   ├── rss_colab_vault_mccann/noticias/   8 noticias ya recogidas con el RSS
│   └── ddg_noticias_mccann_osint/         3 resultados del buscador (uno no es noticia)
├── prompts/prompts_taller.md              todos los prompts, para copiar y pegar
├── descargas_en_vivo/                     aquí va lo que descargues tú en clase
├── checkpoints/                           zips para seguir si te pierdes
└── capturas/                              guarda aquí tus capturas del grafo
```

**Es la misma estructura que usó el profesor para montar el vault completo del caso**, a escala: si entiendes esta carpeta, entiendes el proyecto entero.

**Por qué hay datos ya descargados:** buscar en Google News y en el buscador depende de la red y de que no nos bloqueen cuando lo hacemos 25 personas a la vez. En clase **probamos** que funciona (y lo guardamos en `descargas_en_vivo/`), pero el vault lo montamos con las noticias de `datos/`, que sabemos que salen bien. **Los scripts nunca borran ni sobrescriben** estas carpetas.

### 0.3 · Abre una terminal en la carpeta del kit

- **macOS:** clic derecho en `taller_demo` → *Servicios* → *Nuevo terminal en la carpeta*. O abre Terminal, escribe `cd ` (con espacio) y arrastra la carpeta a la ventana.
- **Windows:** abre `taller_demo` en el Explorador, haz clic en la barra de direcciones, escribe `powershell` y pulsa Intro.
- **Linux:** clic derecho → *Abrir en una terminal*.

Todos los comandos de la guía se ejecutan **desde `taller_demo`**, salvo que se diga otra cosa.

---

## Parte 1 · Obsidian en 12 minutos · DEMO 1

### Paso 1 · Un ejemplo sencillo: una familia

**Qué haces:** sigue el documento **`demo1_familia.md`**. Creas un vault con cuatro personas, unos lugares y un evento, los enlazas, les pones propiedades y los ves como grafo y como mapa de vínculos.

**Por qué:** es exactamente lo que después hará la IA con el caso. Si entiendes **nota, enlace, backlink, propiedades y grafo** con cuatro personas, entenderás el vault del caso con 150 entidades.

**Deberías ver:** un grafo pequeño con las personas en azul, los lugares en verde y el evento en rojo, y un Canvas con tres flechas etiquetadas.

---

## Parte 2 · Recoger las noticias · DEMO 2

Hay dos formas de conseguir noticias, y **no dan lo mismo**:

| | RSS de Google News (paso 2) | Buscador (paso 3) |
|---|---|---|
| Qué te da | **Titular, medio, fecha y enlace.** No el texto: eso lo añadimos después con defuddle | **La URL y el texto** del artículo |
| El pasado | Se puede pedir por ventanas de fechas: cubre todo el caso | Lo que el buscador considere relevante: casi siempre lo reciente |
| Ruido | Poco: solo medios | Mezcla Wikipedia, plataformas de vídeo, páginas de «últimas noticias»… |

### Paso 2 · Noticias por RSS (Colab)

**Qué haces:** ejecutas el notebook `05B` en modo clase: 3 búsquedas en Google News por RSS.

**Por qué:** un **feed RSS** es un fichero que las webs publican para que lo lean programas. Google News crea uno para **cualquier búsqueda**, con sus operadores (`"frase exacta"`, `after:`, `before:`, `site:`…). Así buscamos el caso **año a año** y no solo lo último. El RSS da el **enlace** a cada noticia (una redirección de Google); el notebook lo convierte en la URL real del periódico.

1. Abre https://colab.research.google.com → *Archivo* → *Subir cuaderno* → elige `herramientas/05B_rss_python_caso_mccann.ipynb`.
2. Deja marcado **`MODO_CLASE`** en la celda *Configuración del caso*.
3. *Entorno de ejecución* → *Ejecutar todas*. Tarda 1-2 minutos.
4. Al final se descarga `vault_mccann.zip`. Guárdalo en `descargas_en_vivo/` y ábrelo: son notas `.md` con propiedades (medio, fecha, URL…) y la línea *«Texto del artículo pendiente de extraer con defuddle»*.

**Deberías ver:** en la celda 2.3, tres líneas con las noticias encontradas en cada ventana de tiempo, y en la 2.5, un gráfico con las noticias por año.

**Para pensar:** en la celda 2.1, sin ventanas de fechas, ¿de qué años son las noticias? ¿Por qué 2007 no aparece si fue cuando más se publicó?

> **En casa, versión completa:** desmarca `MODO_CLASE`. Hace unas 90 búsquedas (5-7 minutos) y saca 100-120 noticias de 2007 a hoy.

### Paso 3 · Noticias con un buscador (script)

**Qué haces:** ejecutas `osint_news_scraper.py`, que busca en un buscador y **descarga el texto** de cada resultado.

**Por qué:** es la otra vía. Te da el texto directamente, pero sin controlar las fechas y con ruido. Usa la librería `ddgs`, que en realidad es un **metabuscador**: consulta DuckDuckGo, Bing, Yahoo y otros.

Primero, **una sola vez**, crea un entorno virtual (una instalación de Python solo para este taller) e instala las librerías:

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install requests beautifulsoup4 ddgs
```

**Windows (PowerShell):**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install requests beautifulsoup4 ddgs
```

> Si PowerShell dice que «la ejecución de scripts está deshabilitada»: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` y repite la segunda línea.

Después, ejecuta el script **dentro de `descargas_en_vivo`**:

**macOS / Linux:**
```bash
cd descargas_en_vivo
python3 ../herramientas/osint_news_scraper.py
cd ..
```

**Windows:**
```powershell
cd descargas_en_vivo
python ..\herramientas\osint_news_scraper.py
cd ..
```

**Deberías ver:** una línea por búsqueda con «N enlaces nuevos» y, al final, la carpeta `descargas_en_vivo/noticias_mccann_osint/` con un `.txt` por artículo: titular, URL, fecha, medio y texto. Ábrelos y compáralos con el RSS: **¿de qué años son?**

> Si da 0 enlaces, te están limitando: espera unos minutos. No pasa nada, porque en `datos/ddg_noticias_mccann_osint/` tienes resultados ya descargados. Si lo ejecutas dos veces, **no borra nada**: la segunda vez crea otra carpeta con la fecha y la hora.

### Paso 4 · Apartar lo que no es noticia

**Qué haces:** ejecutas `separar_no_noticias.py` sobre los resultados del buscador.

**Por qué:** si dejamos entrar Wikipedia o una página de «últimas noticias sobre…», la IA sacará entidades de algo que **no es prensa**. El script decide con tres reglas que puedes leer y discutir: el **dominio** (wikipedia.org, netflix.com…), la **ruta** de la URL (`/temas/`, `/tag/`…) y **frases del titular** («últimas noticias»). **No borra nada:** mueve a otra carpeta y explica el motivo.

Primero **simula**, para ver qué haría:
```bash
python3 herramientas/separar_no_noticias.py datos/ddg_noticias_mccann_osint
```
Si estás de acuerdo, **mueve**:
```bash
python3 herramientas/separar_no_noticias.py datos/ddg_noticias_mccann_osint --destino datos/ddg_descartadas_no_noticia --mover
```
(En Windows, `python` en lugar de `python3` y `\` en lugar de `/`.)

**Deberías ver:** `1 de 3 no parecen noticias`: la de Wikipedia, con el motivo «dominio no periodístico». Queda en `datos/ddg_descartadas_no_noticia/`, y todas las decisiones, en `datos/ddg_noticias_mccann_osint_informe_separacion.csv`.

**Para pensar:** pruébalo también con lo que descargaste tú en el paso 3 (`descargas_en_vivo/noticias_mccann_osint`). ¿Hay alguna decisión con la que no estés de acuerdo? ¿Qué regla añadirías?

---

## Parte 3 · Montar el vault · DEMO 3

### Paso 5 · Las skills de Obsidian (GitHub de kepano)

**Qué haces:** conoces qué es una *skill*, lees una y descargas el paquete.

**Por qué:** una **skill** es un **manual en Markdown escrito para una IA**: qué herramienta usar, con qué comando y qué devuelve. La IA solo lee el nombre y la descripción de cada skill hasta que la necesita, y entonces lee el resto. Steph Ango (*kepano*), CEO de Obsidian, publica seis skills para trabajar con vaults.

1. Abre https://github.com/kepano/obsidian-skills y mira el README: qué skills hay y cómo se instalan.
2. Entra en `skills/defuddle/SKILL.md` y **léelo entero**: son unas 30 líneas. Fíjate en la cabecera (`name`, `description`) y en que el resto son instrucciones en lenguaje normal.
3. **El kit ya las trae** en `herramientas/obsidian-skills/`, por si Git o la red fallan en clase. Para ver cómo se descargan, clónalas en `descargas_en_vivo/`:

```bash
cd descargas_en_vivo
git clone https://github.com/kepano/obsidian-skills.git
cd ..
```
(Igual en Windows.) Compara las dos carpetas: son lo mismo.

| Skill | Qué le enseña a la IA | ¿La usamos? |
|---|---|---|
| `obsidian-markdown` | Notas con enlaces, propiedades y avisos | Sí |
| `json-canvas` | Lienzos `.canvas`: mapas y cronologías | Sí |
| `defuddle` | Sacar el artículo limpio de una web | Sí |
| `obsidian-bases` | Tablas `.base` sobre las propiedades | Opcional |
| `obsidian-cli` | Manejar Obsidian desde la terminal | No |
| `knap` | Generar notas desde plantillas y CSV | No |

**Deberías ver:** seis subcarpetas en `obsidian-skills/skills/`, cada una con su `SKILL.md`.

### Paso 6 · defuddle: el artículo sin lo demás

**Qué haces:** instalas defuddle y lo pruebas con una noticia.

**Por qué:** una página de un periódico tiene menús, anuncios, cookies y enlaces a otras noticias. **defuddle** (también de kepano; nació para el *Web Clipper* de Obsidian) se queda **solo con el artículo** y lo devuelve en Markdown. Es lo que añade el texto a las noticias del RSS.

```bash
npm install -g defuddle
defuddle parse "https://www.theguardian.com/uk/2007/may/04/markoliver" --md
```

**Deberías ver:** el texto de la noticia en Markdown, sin menús ni publicidad.

> Si dice «command not found» o «no se reconoce»: cierra la terminal, ábrela de nuevo y repite. Si sigue, comprueba `node --version`.

**Para pensar:** prueba con una noticia de *The Telegraph*. ¿Qué pasa? *(Pista: código 402, Payment Required.)* Si un medio entero queda fuera por su muro de pago, ¿qué sesgo introduce eso en tu análisis?

### Paso 7 · Montar el vault con `preparar_vault.py`

**Qué haces:** un script junta las dos fuentes, descarga el texto de cada noticia y crea el vault.

**Por qué:** es el trabajo repetitivo que no queremos hacer a mano. El script:
1. copia las noticias del RSS a `vault_demo/noticias/`;
2. convierte los `.txt` del buscador en notas con las mismas propiedades, y **salta las que ya estaban en el RSS** (misma URL);
3. con `--defuddle`, descarga el texto de cada noticia del RSS (4 a la vez) y apunta en la propiedad `texto` si lo consiguió (`defuddle`) o no (`fallo`);
4. crea las carpetas de entidades, copia las reglas como `CLAUDE.md`, copia las skills en `.claude/skills/` y deja los colores del grafo configurados;
5. escribe `_informe_preparacion.md` con lo que ha fallado y por qué.

**macOS / Linux:**
```bash
python3 herramientas/preparar_vault.py --rss datos/rss_colab_vault_mccann --ddg datos/ddg_noticias_mccann_osint --salida vault_demo --defuddle --skills herramientas/obsidian-skills/skills
```

**Windows:**
```powershell
python herramientas\preparar_vault.py --rss datos\rss_colab_vault_mccann --ddg datos\ddg_noticias_mccann_osint --salida vault_demo --defuddle --skills herramientas\obsidian-skills\skills
```

**Deberías ver:**
```
[RSS] 8 notas copiadas
[DDG] 2 notas creadas, 0 descartadas por estar ya en el RSS
[defuddle] 8 noticias por descargar con 4 hilos…
[defuddle] 8/8 con texto
Vault listo en vault_demo/ con 10 noticias.
```

> Si te equivocas en una ruta, el script **se para antes de empezar** y te sugiere la correcta.
> Si `vault_demo` ya tenía noticias, también **se para y no toca nada**: así no pierdes trabajo. Usa otro nombre en `--salida`, o añade `--forzar` si de verdad quieres rehacerlo.

**Si te has perdido** (o no tienes Node): descomprime `checkpoints/pc_paso7_vault_demo_con_texto.zip` en `taller_demo/`. Tendrás `vault_demo/` exactamente como queda tras este paso.

### Paso 8 · Abrir el vault en Obsidian

**Qué haces:** abres `vault_demo` como vault nuevo, en otra ventana.

1. En Obsidian, abajo a la izquierda, clic en el nombre del vault actual → **Gestionar bóvedas** → **Abrir carpeta como bóveda** → elige `taller_demo/vault_demo`.
2. Abre un par de noticias: arriba están sus **propiedades** (medio, fecha, url, origen, texto) y abajo, el artículo.
3. Abre la vista de grafo (`Cmd/Ctrl + G`).

**Deberías ver:** **10 puntos sueltos**. Las noticias todavía no se enlazan entre sí: no sabemos quién aparece en cada una. Eso es lo que hará la IA.

> Abre siempre la carpeta `vault_demo`, **no** `taller_demo`: si abres la de arriba, Obsidian mezcla las notas del vault con los datos y las herramientas.

---

## Parte 4 · La IA extrae las entidades · DEMO 3 (continuación)

### Paso 9 · Arrancar el agente dentro del vault

**Qué haces:** abres un agente de IA **en la carpeta `vault_demo`** y compruebas que ve las reglas y las skills.

**Por qué:** necesitamos una IA que **lea y escriba ficheros**, no un chat. Y tiene que arrancar en el vault: es ahí donde busca el fichero de reglas y las skills. Es el error más común.

| Agente | Cómo arrancarlo | Fichero de reglas que lee | Skills |
|---|---|---|---|
| **Claude Code** (terminal, VS Code o app de escritorio) | `cd vault_demo` y `claude` | `CLAUDE.md` (ya está) | `.claude/skills/` (ya están) |
| **Codex CLI** | `cd vault_demo` y `codex` | `AGENTS.md`: copia `CLAUDE.md` con ese nombre | Copia `herramientas/obsidian-skills/skills/*` a `~/.codex/skills/` |
| **OpenCode** | `cd vault_demo` y `opencode` | `AGENTS.md`: copia `CLAUDE.md` con ese nombre | Clona el repositorio en `~/.opencode/skills/obsidian-skills` |
| **Gemini CLI** | `cd vault_demo` y `gemini` | `GEMINI.md`: copia `CLAUDE.md` con ese nombre | Consulta su documentación |

Para casi cualquier agente también vale: `npx skills add https://github.com/kepano/obsidian-skills`

> **Instalar Claude Code:** `npm install -g @anthropic-ai/claude-code` (necesita una cuenta de Claude). **Sin agente:** en un chat de IA, sube 2-3 noticias y `CLAUDE.md`, pide las notas de entidad en Markdown y guárdalas tú en `entidades/`. Sirve para entender el proceso.

Abre `CLAUDE.md` y léelo: son las **reglas del vault**. Las más importantes:
1. **Cada afirmación, con su fuente:** una frase sin enlace a una noticia no se escribe.
2. **No duplicar:** antes de crear una entidad, buscar si ya existe (también por alias).
3. **Quién actúa:** en los eventos, quién los ejecutó (qué policía, qué fiscalía…).
4. **Lenguaje de las fuentes:** «sospechoso», «arguido» y «condenado» no son sinónimos.
5. **Contradicciones a la vista:** si dos medios discrepan, las dos versiones y un aviso.

Comprueba que el agente lo ve todo:
```
Ejecuta pwd y dime en qué carpeta estás. Después: ¿qué skills tienes disponibles y qué reglas hay en CLAUDE.md? Responde en una lista corta.
```

**Deberías ver:** que está en `…/taller_demo/vault_demo`, que nombra las skills de Obsidian (`defuddle`, `json-canvas`, `obsidian-markdown`…) y que resume las reglas.

### Paso 10 · Un prompt que lo procesa todo

**Qué haces:** con un solo prompt, la IA lee las 10 noticias, crea las fichas de las entidades, las enlaza y hace un mapa de contenido.

**Por qué:** esto **no es entrenar un modelo**. La IA no aprende nada: **lee nuestros ficheros en ese momento** y trabaja sobre ellos (es darle contexto, al estilo RAG), y al cerrar la conversación no recuerda nada. Por eso la regla 1 es tan importante: la IA también «sabe» cosas del caso por su entrenamiento, y exigir la fuente de cada frase es lo que separa **lo que dicen las noticias** de **lo que cree saber el modelo**.

Copia y pega:
```
Lee CLAUDE.md y usa la skill obsidian-markdown. Procesa TODAS las noticias de noticias/ (son 10):

1. Para cada noticia, extrae las personas, lugares, organizaciones y eventos relevantes y crea o actualiza su nota en entidades/ siguiendo exactamente la plantilla y las reglas de CLAUDE.md. Antes de crear una entidad, comprueba si ya existe (también por alias).
2. En cada evento, indica en "## Relaciones" quién lo ejecutó o protagonizó, si la noticia lo dice (regla 5b).
3. Añade al final de cada noticia la sección "## Entidades" con los enlaces, agrupados por tipo.
4. Crea "MOC - Caso McCann.md", el mapa de contenido del vault: un párrafo de contexto (con sus fuentes) y las secciones Personas, Lugares, Organizaciones, Eventos (por fecha) y Contradicciones.

Al terminar, dame: una tabla de entidades por tipo con su número de fuentes, las contradicciones que hayas encontrado y las decisiones que hayas tomado por prudencia.
```

Tarda unos minutos. **Mientras trabaja, mira Obsidian:** verás aparecer las notas en `entidades/` y el grafo enlazándose en directo.

**Deberías ver:** unas 30-50 entidades y el grafo convertido en una red, con las noticias conectadas **a través de las personas y lugares que comparten**.

**Si te has perdido:** sigue mirando la pantalla del profesor; el prompt es el mismo y puedes lanzarlo en casa sobre `checkpoints/pc_paso7_vault_demo_con_texto.zip`.

### Paso 11 · Revisar lo que ha hecho la IA

**Qué haces:** compruebas que el resultado respeta las reglas.

**Por qué:** una IA que resume **también se equivoca**: puede atribuir a una persona algo que la fuente no dice, o enlazar a quien no toca. En inteligencia, un error de atribución sobre una persona es grave. **La última pieza del proceso eres tú.**

1. Que la IA se revise a sí misma:
```
Revisa las notas de entidades/ y dame una lista de: (1) frases sin enlace a una noticia; (2) enlaces a notas que no existen; (3) afirmaciones sobre culpabilidad que no estén literalmente en la fuente. No corrijas nada todavía.
```
2. Y a mano: abre **dos entidades**, elige una frase de cada una, abre la noticia que cita y comprueba que dice eso.

**Deberías ver:** pocas o ninguna frase sin fuente. Si aparecen, pide que las corrija o las borre.

---

## Parte 5 · Ver el resultado · ANÁLISIS

### Paso 12 · El grafo: de mapa de fuentes a mapa de entidades

**Qué haces:** filtras el grafo para quitar las noticias.

**Por qué:** tal como sale, el grafo es un **mapa de fuentes**: cada noticia enlaza a sus entidades y las entidades muy citadas se convierten en nudos gordos. Responde a *«¿quién sale en qué noticia?»*. Si quitamos las noticias, queda la red de **entidades unidas por sus relaciones**.

Vista de grafo → ajustes (rueda dentada) → **Filtros** → *Buscar archivos*:
```
path:entidades -path:"entidades/eventos/Desaparición de Madeleine McCann.md"
```

| Ajuste | Valor |
|---|---|
| Filtros → Huérfanos | desactivado |
| Grupos | ya vienen configurados: personas azul, lugares verde, organizaciones naranja, eventos rojo |
| Mostrar → Flechas | activado |
| Fuerzas → Fuerza de repulsión | al máximo |

Prueba también el **grafo local**: abre una persona → menú `⋯` → *Abrir grafo local* → profundidad 2.

**Deberías ver:** menos nodos, en colores, y las relaciones entre ellos. Pero las líneas **no dicen qué relación hay**: para eso, el paso 13.

### Paso 13 · El mapa de vínculos (Canvas)

**Qué haces:** pides a la IA un **mapa de vínculos** (un *link chart*, como los de una investigación policial) centrado en una persona, con **flechas con dirección y tipo de relación**.

**Por qué:** el grafo de Obsidian dibuja todas las líneas iguales; un Canvas permite flechas etiquetadas («su abogado», «declaró arguido a»). Es lo que hiciste a mano con la familia en la demo 1. Con las 10 noticias del kit, una buena persona central es **Christian Brueckner**, que aparece en las noticias de 2020 a 2026. Prueba también con **Robert Murat**, que sale en las de 2007-2008.

```
Lee CLAUDE.md y usa la skill json-canvas. Crea un MAPA DE VÍNCULOS (link chart) centrado en una persona.

PERSONA CENTRAL: Christian Brueckner

DATOS: solo las secciones "## Relaciones" de entidades/. No leas noticias ni uses lo que sepas del caso.

QUÉ ENTIDADES ENTRAN:
- Nivel 1: toda entidad que aparezca en una relación de la persona central, o que tenga una relación hacia ella.
- Nivel 2: las personas y organizaciones que tengan relación con los EVENTOS del nivel 1. No añadas lugares ni eventos de nivel 2.
- Excluye las noticias y el evento genérico "Desaparición de Madeleine McCann". Máximo 30 nodos.

REGLAS DE LAS FLECHAS:
1. El destino de cada flecha es EXACTAMENTE la entidad enlazada en esa línea de Relaciones. Si no está en el mapa, añádela; nunca la redirijas a otra parecida.
2. Una sola flecha por par de entidades; si hay varias relaciones, júntalas en una etiqueta.
3. Los eventos no son actores: la flecha va de quien actúa al evento o a la persona afectada.
4. Gris "#9ca3af" y "(?)" SOLO si es una afirmación de parte (el propio implicado, su entorno o su abogado) o tiene un aviso de contradicción. Lo que la fuente da como hecho, en negro.
5. Etiqueta de 2 a 5 palabras, en español, con el año si la relación cambió con el tiempo.

NODOS: cada entidad es un nodo de tipo "file" que apunta a su nota. Colores: personas "#3b82f6", organizaciones "#f59e0b", lugares "#22c55e", eventos "#ef4444", persona central "#8b5cf6". Persona central en el centro; personas arriba, organizaciones a la derecha, lugares abajo, eventos a la izquierda ordenados por fecha. Al menos 120 px entre nodos. Añade un grupo "Leyenda".

Guarda el resultado como "mapas/Mapa de vínculos - Christian Brueckner.canvas".
Al terminar: tabla origen → etiqueta → destino → nota de la que sale, y la lista de flechas grises con su motivo.
```

**Deberías ver:** en `mapas/`, un Canvas con Brueckner en el centro, flechas etiquetadas y una leyenda de colores. Cada tarjeta se abre con doble clic.

> **Verifícalo:** elige 3 flechas y comprueba que esa relación está en la sección «Relaciones» de la nota de origen. En clase, un mapa de prueba mandó una flecha a *Praia da Luz* cuando la nota decía *Lagos*: un mapa de vínculos con un error sitúa a una persona donde la fuente no la sitúa.

---

## Parte 6 · Qué podemos ver en Obsidian: mini ejercicios

Hazlos con tu `vault_demo`. Con el caso completo (parte 7) salen muchas más cosas. Para cada ejercicio, apunta **qué nota o vista has usado**.

**1. ¿Con quién se relaciona una persona?** *(grafo local)*
Abre Christian Brueckner → *Abrir grafo local* → profundidad 1. ¿Qué organizaciones aparecen? ¿De qué países son? Sube a profundidad 2: ¿qué entra nuevo?

**2. ¿Dónde más aparece esto?** *(backlinks)*
Abre la nota de **Praia da Luz** y mira **Menciones enlazadas**. ¿Cuántas noticias la citan? ¿De qué años? ¿Qué te dice eso del caso?

**3. ¿En qué discrepan los medios?** *(búsqueda de avisos)*
`Cmd/Ctrl + Mayús + F` y busca `[!warning]`. Elige una contradicción, abre las **dos** noticias que cita y decide cuál es más fiable. ¿Por qué?

**4. ¿Qué está poco fundamentado?** *(búsqueda por propiedades)*
Busca `[n_fuentes:1]`. Son las entidades que salen de **una sola noticia**. Elige una: ¿la meterías en un informe? ¿Qué harías para confirmarla?

**5. ¿Quién actúa?** *(filtro por tipo)*
En el grafo, filtra por `path:entidades/organizaciones OR path:entidades/eventos`. ¿Qué organización ejecuta más eventos? ¿En qué años entra cada una en el caso?

**6. ¿Es fiable el mapa de vínculos?** *(verificación)*
En tu Canvas, elige **3 flechas** y comprueba cada una en la sección «Relaciones» de su nota de origen. ¿Alguna mal dirigida, mal etiquetada o hacia la entidad equivocada?

**7. ¿Qué nos falta?** *(comparar)*
Compara tu `vault_demo` (10 noticias) con el vault completo que se enseña en clase (o con el tuyo, si haces la parte 7). ¿Qué persona o lugar importante no aparece con 10 noticias? ¿Qué conclusiones cambiarían si solo tuvieras tu vault?

**Para cerrar, una pregunta:** alguien escribe en un informe *«Christian Brueckner era el sospechoso desde 2020, según 40 fuentes»*. Con lo que sabes de cómo se ha construido el vault, ¿qué comprobarías primero y qué palabra cambiarías?

---

## Parte 7 · En casa: el caso completo

En clase trabajamos con **10 noticias por tiempo**. El proceso es idéntico al del caso completo que se enseña en clase (132 noticias y unas 150 entidades); solo cambia la escala. Con este mismo kit puedes hacerlo a escala real:

1. **Más noticias del RSS:** en el Colab (`herramientas/05B…`), **desmarca `MODO_CLASE`** y ejecuta todo. Hace unas 90 búsquedas (5-7 minutos) y saca 100-120 noticias de 2007 a hoy. Descomprime el `vault_mccann.zip` que descarga en `descargas_en_vivo/rss_completo/` (tiene que quedar `descargas_en_vivo/rss_completo/noticias/*.md`).
2. **Más resultados del buscador:** el script del paso 3 ya los deja en `descargas_en_vivo/noticias_mccann_osint/`. Pásales el filtro del paso 4:
   ```bash
   python3 herramientas/separar_no_noticias.py descargas_en_vivo/noticias_mccann_osint --destino descargas_en_vivo/descartadas --mover
   ```
3. **Monta un vault nuevo** (con otro nombre, para no pisar `vault_demo`):
   ```bash
   python3 herramientas/preparar_vault.py --rss descargas_en_vivo/rss_completo --ddg descargas_en_vivo/noticias_mccann_osint --salida vault_completo --defuddle --skills herramientas/obsidian-skills/skills
   ```
4. **La IA, por lotes:** 130 noticias no caben en un solo prompt. Usa este, cambiando los prefijos por años (`2007-05, 2007-06…`, luego `2008`, luego `2009, 2010, 2011, 2012`…) y empieza **conversación nueva** cada 2-3 lotes:
   ```
   Lee CLAUDE.md. Procesa, con sus reglas, todas las noticias de noticias/ cuyo nombre empiece por [PREFIJOS], excepto las que ya tengan "## Entidades".
   Antes de crear una entidad, comprueba si ya existe en entidades/ (también por alias). Al terminar: noticias procesadas, entidades creadas y actualizadas, contradicciones nuevas y decisiones por prudencia.
   ```
5. **Limpia duplicados** al final (con tantas noticias, siempre aparecen):
   ```
   Revisa entidades/ en busca de duplicados: la misma persona, lugar u organización con nombres distintos (idiomas, grafías, siglas). Para cada grupo, propón cuál se queda y qué alias añadir. NO cambies nada hasta que te lo confirme.
   ```
6. Después, los pasos 11 a 13 y los ejercicios de la parte 6, igual que con 10 noticias.

## Problemas típicos

| Síntoma | Qué hacer |
|---|---|
| `python3` / `python` no se reconoce | En Windows, reinstala Python marcando «Add Python to PATH», o usa `py` |
| El Colab da 0 noticias | Google te está frenando: espera unos minutos. Tienes las noticias en `datos/` |
| El script del buscador da 0 enlaces | Comprueba que instalaste `ddgs`. Si sigue, espera: te están limitando |
| `defuddle` no se reconoce | Cierra y abre la terminal. Comprueba `node --version`. Plan B: `checkpoints/pc_paso7…` |
| `can't open file …py` | Estás en otra carpeta: los comandos se lanzan desde `taller_demo/` y los scripts llevan delante `herramientas/` |
| `preparar_vault.py` dice que una ruta no existe | Copia el comando de esta guía; te sugiere la ruta buena |
| `preparar_vault.py` dice que ya hay noticias | Es a propósito, para no pisarte. Usa otra `--salida` o `--forzar` |
| La IA dice que no hay `CLAUDE.md` o no ve las skills | No está arrancada en `vault_demo`. Ciérrala y ábrela dentro de esa carpeta |
| Frases sin fuente en las entidades | La IA está tirando de lo que «sabe». Recuérdale la regla 1 de `CLAUDE.md` |
| El grafo es una bola ilegible | Paso 12: filtro `path:entidades` y repulsión al máximo |

---

## Enlaces del taller

- Obsidian: https://obsidian.md · ayuda: https://help.obsidian.md
- Skills de kepano: https://github.com/kepano/obsidian-skills
- defuddle: https://github.com/kepano/defuddle
- Formato JSON Canvas: https://jsoncanvas.org
- Google Colab: https://colab.research.google.com
- Google News por RSS (ejemplo): https://news.google.com/rss/search?q=%22Madeleine+McCann%22&hl=en-GB&gl=GB&ceid=GB:en
