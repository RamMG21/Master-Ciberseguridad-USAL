#!/usr/bin/env python3
"""
separar_no_noticias.py · Taller de Obsidian (Ciberinteligencia, USAL)
----------------------------------------------------------------------
Revisa los .txt que genera osint_news_scraper.py y aparta los resultados
que NO son noticias: enciclopedias, plataformas de vídeo, portadas de tema
o de etiqueta («últimas noticias sobre…»), etc.

No borra nada: los MUEVE a una carpeta aparte y deja un informe con el
motivo de cada decisión. Por defecto solo SIMULA; añade --mover para
moverlos de verdad.

Uso:
  python separar_no_noticias.py noticias_mccann_osint            # simula
  python separar_no_noticias.py noticias_mccann_osint --mover    # mueve

Funciona igual en Windows, macOS y Linux (solo biblioteca estándar).
----------------------------------------------------------------------
"""
import argparse
import csv
import re
import shutil
from pathlib import Path
from urllib.parse import urlparse

# 1) Dominios que no son prensa
DOMINIOS_NO_PRENSA = [
    "wikipedia.org", "wikiwand.com", "netflix.com", "primevideo.com", "youtube.com",
    "imdb.com", "filmaffinity.com", "facebook.com", "instagram.com", "tiktok.com",
    "x.com", "twitter.com", "reddit.com", "pinterest.com", "amazon.",
]

# 2) Trozos de ruta típicos de páginas de tema o etiqueta (listados de noticias)
RUTAS_DE_TEMA = ["/temas/", "/tema/", "/tag/", "/tags/", "/topic/", "/topics/",
                 "/etiqueta/", "/etiquetas/", "/hub/", "/keyword/"]

# 3) Frases del titular que delatan un listado, no una noticia
TITULARES_DE_LISTADO = ["últimas noticias", "ultimas noticias", "latest news", "noticias sobre",
                        "videos y fotos", "vídeos y fotos", "sitio oficial", "wikipedia",
                        "all the latest", "news and updates"]


def motivo_descarte(url, titular):
    """Devuelve el motivo por el que NO es una noticia, o None si lo parece."""
    u = urlparse(url)
    dominio = u.netloc.lower()
    ruta = u.path.lower()
    t = titular.lower()
    for d in DOMINIOS_NO_PRENSA:
        if d in dominio:
            return f"dominio no periodístico ({d})"
    for r in RUTAS_DE_TEMA:
        if r in ruta:
            return f"página de tema o etiqueta ({r})"
    for frase in TITULARES_DE_LISTADO:
        if frase in t:
            return f"titular de listado («{frase}»)"
    # Ruta muy corta y sin números (p. ej. /noticias/madeleine-mccann/): suele ser una portada de tema.
    trozos = [p for p in ruta.split("/") if p]
    if len(trozos) <= 2 and not re.search(r"\d", ruta):
        return "ruta corta sin fecha ni identificador (portada de tema)"
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("carpeta", type=Path, help="carpeta con los .txt del script de noticias")
    ap.add_argument("--destino", type=Path, help="adónde moverlas (por defecto: <carpeta>_descartadas)")
    ap.add_argument("--mover", action="store_true", help="moverlas de verdad (si no, solo simula)")
    a = ap.parse_args()

    destino = a.destino or a.carpeta.with_name(a.carpeta.name + "_descartadas")
    filas, n_desc = [], 0
    for txt in sorted(a.carpeta.glob("*.txt")):
        crudo = txt.read_text(encoding="utf-8", errors="replace")
        titular = crudo.split("\n", 1)[0].lstrip("# ").strip()
        m = re.search(r"^URL:\s*(\S+)", crudo, flags=re.M)
        url = m.group(1) if m else ""
        motivo = motivo_descarte(url, titular)
        filas.append({"fichero": txt.name, "decision": "descartar" if motivo else "mantener",
                      "motivo": motivo or "", "url": url, "titular": titular})
        if motivo:
            n_desc += 1
            print(f"[DESCARTAR] {titular[:70]}\n            {url}\n            → {motivo}")
            if a.mover:
                destino.mkdir(exist_ok=True)
                shutil.move(str(txt), str(destino / txt.name))

    informe = a.carpeta.with_name(a.carpeta.name + "_informe_separacion.csv")
    with open(informe, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["fichero", "decision", "motivo", "url", "titular"])
        w.writeheader()
        w.writerows(filas)

    print(f"\n{n_desc} de {len(filas)} no parecen noticias.")
    print(f"Informe con todas las decisiones: {informe}")
    if a.mover:
        print(f"Movidas a: {destino}")
    else:
        print("Esto ha sido una SIMULACIÓN. Revisa la lista y, si estás de acuerdo, repite con --mover")


if __name__ == "__main__":
    main()
