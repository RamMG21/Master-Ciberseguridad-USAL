---
tipo: noticia
titular: "Madeleine McCann's parents officially cleared as police shelve investigation"
medio: "The Mirror"
fecha: 2008-07-21
url: "https://www.mirror.co.uk/news/madeleine-mccanns-parents-officially-cleared-729039"
url_google: "https://news.google.com/rss/articles/CBMiiAFBVV95cUxPcnVBcU1zLXFsUUpfek9vMGFhYjhUWl8wWDdJY2ltX0dZSHc3R0dhQ0VuZGluUzNZMzFzMWJDYklPYURDZXFqbUxHYWEtc09scWNmSGR4Rlc5dnJUU2QyaHFsWXZTY0x3MjB0T1htVVJvX2dYX2xwem55SzJ2Z2o1OHRaWHhTRlps0gGOAUFVX3lxTE5HMlVkS3RaazJqa3UtM2lmZi1jaTgxMUViMWg2X2ljRWJqbVlhRkJoMnl6b2gwRFBoQkxoaWxVTlVmQTFyMlhTLURpZFNCZUpZd1hETnpqWmFVZ19zUEFaQTFxby1CbmhxdG1SRDU0Z0VBV09GU1h3OXRPNkVpcndzZVc0UlFhLUhsTm9uakE?oc=5"
edicion: "Reino Unido"
ventana: "2008-T3"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2008-07-01 before:2008-10-01"
puntos: 2
motivo: "+ police, investigation"
capturado: "2026-09-25T14:58:10"
tags: [noticia, mccann]
---

# Madeleine McCann's parents officially cleared as police shelve investigation

> Texto del artículo pendiente de extraer con defuddle.
