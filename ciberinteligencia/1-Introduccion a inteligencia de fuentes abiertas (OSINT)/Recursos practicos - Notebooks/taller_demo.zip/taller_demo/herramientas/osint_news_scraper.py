#!/usr/bin/env python3
"""
osint_news_scraper.py
----------------------------------------------------------------------
Script de recuperación de noticias (OSINT) para un caso concreto.

QUÉ HACE
    1) Busca en DuckDuckGo una lista de consultas relacionadas con un
       caso/tema, y reúne las URLs de resultados únicos.
    2) Descarga cada URL y extrae el texto del artículo (párrafos +
       título), filtrando el contenido irrelevante (nav, menús, etc.).
    3) Se queda solo con los artículos que:
         - contienen alguna palabra clave positiva del caso, y
         - NO contienen ninguna palabra clave negativa (para descartar
           falsos positivos, p. ej. resultados que solo coinciden por
           casualidad con un término genérico), y
         - tienen una longitud de texto mínima (para descartar páginas
           vacías, muros de cookies, error 404 "camuflado", etc.).
    4) Guarda cada noticia válida como un .txt individual en una carpeta
       de salida, hasta alcanzar un número objetivo de noticias.
    5) Comprime la carpeta en un .zip final, listo para usarse como
       "corpus" de trabajo (por ejemplo, para dárselo de contexto a un
       LLM y organizar los hallazgos en Obsidian).

CÓMO PERSONALIZARLO
    Todo lo que hay que tocar para adaptar el script a OTRO caso está
    en el bloque "CONFIGURACIÓN" de más abajo: nombre del caso, lista
    de búsquedas, palabras clave positivas/negativas y parámetros de
    ejecución. El resto del código es genérico y no hace falta tocarlo.

NOTA ÉTICA / LEGAL (léela antes de usarlo)
    - Este script solo recopila y reorganiza información YA PUBLICADA
      públicamente por medios de comunicación; no accede a fuentes
      privadas ni intenta identificar/localizar a nadie por su cuenta.
    - Respeta el robots.txt y los términos de uso de cada sitio si vas
      a reutilizar este patrón fuera de un ejercicio educativo: aquí no
      se ha implementado esa comprobación para mantener el ejemplo
      simple, pero es una limitación a mencionar en el taller.
    - "Entrenar un modelo" con estas noticias, en el sentido que se usa
      coloquialmente aquí, NO es fine-tuning: es dar contexto (estilo
      RAG) a un LLM para que lea, resuma y estructure la información.
      Merece la pena dejarlo explícito en el taller para no generar
      una idea equivocada de lo que es "entrenar" un modelo.
----------------------------------------------------------------------
"""

import os
import re
import shutil
import logging
import warnings
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup
try:
    from ddgs import DDGS                 # nombre actual de la librería (pip install ddgs)
except ImportError:
    from duckduckgo_search import DDGS    # nombre antiguo: ya no devuelve resultados
import time

# ======================================================================
# CONFIGURACIÓN — esto es lo único que hay que cambiar para otro caso
# ======================================================================

# Nombre corto del caso, se usa para nombrar carpeta y zip de salida
CASE_NAME = "mccann_osint"

# Consultas que se lanzarán en DuckDuckGo. Cuantas más variantes
# (idiomas, sinónimos, nombres propios, fechas), más cobertura.
QUERY_LIST = [
    "Madeleine McCann news 2024",
    "Christian Brueckner Maddie McCann trial updates",
    "Maddie McCann search evidence 2024",
    "noticias desaparición Madeleine McCann hoy",
    "investigación Maddie McCann fiscalía alemana",
    "Kate and Gerry McCann latest statement",
    "Madeleine McCann case latest suspect",
    "noticias juicio Christian Brueckner",
]

# Palabras clave positivas: el artículo debe contener AL MENOS UNA
# (se comparan en minúsculas y sin acentos, ver normalize_text)
KEYWORDS_FILTER = ["mccann", "brueckner", "maddie"]

# Palabras clave negativas: si el artículo contiene CUALQUIERA de
# estas, se descarta aunque cumpla el filtro positivo. Sirve para
# eliminar falsos positivos (p. ej. "maddie" coincidiendo con una
# receta de cocina o una web de repostería sin relación con el caso).
NEGATIVE_KEYWORDS = ["recipe", "cake", "bakery", "cookies", "cook", "receta"]

TARGET_COUNT = 50          # nº de noticias válidas que se quiere reunir
MAX_RESULTS_PER_QUERY = 35 # resultados que se piden a DDG por consulta
MIN_CONTENT_LENGTH = 400   # caracteres mínimos para considerar el artículo válido
REQUEST_TIMEOUT = 8        # segundos de timeout por petición HTTP
MAX_WORKERS = 10           # hilos concurrentes para descargar artículos

OUTPUT_DIR = f"noticias_{CASE_NAME}"   # si ya existe, se crea otra con fecha y hora (nunca se borra nada)
ZIP_NAME = f"noticias_{CASE_NAME}.zip"

# ======================================================================
# Silenciar ruido de librerías (avisos de deprecación, SSL, logs de red)
# ======================================================================
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)
try:
    from urllib3.exceptions import InsecureRequestWarning
    warnings.filterwarnings("ignore", category=InsecureRequestWarning)
except ImportError:
    pass

logging.getLogger("duckduckgo_search").setLevel(logging.CRITICAL)
logging.getLogger("ddgs").setLevel(logging.CRITICAL)
logging.getLogger("urllib3").setLevel(logging.CRITICAL)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
}

# Etiquetas HTML que no aportan contenido de artículo y se descartan
# antes de extraer el texto (menús, scripts, cabeceras, publicidad...)
NOISE_TAGS = ["script", "style", "nav", "footer", "header", "aside", "form", "iframe"]


def normalize_text(text: str) -> str:
    """Minúsculas y sin acentos, para comparar palabras clave sin
    depender de mayúsculas/tildes (p. ej. 'McCann' == 'mccann')."""
    if not text:
        return ""
    text = unicodedata.normalize("NFD", text)
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    return text.lower()


def safe_filename(title: str, max_len: int = 80) -> str:
    """Convierte un título de noticia en un nombre de fichero válido
    en cualquier sistema operativo (sin barras, dos puntos, etc.)."""
    title = title or "sin_titulo"
    cleaned = "".join(c if (c.isalnum() or c in " _-") else "_" for c in title)
    cleaned = re.sub(r"_+", "_", cleaned).strip("_ ")
    return cleaned[:max_len] if cleaned else "sin_titulo"


def search_links(query_list, max_results_per_query) -> dict:
    """Fase 1: lanza cada query en DuckDuckGo y devuelve un diccionario
    {url: {"fecha": ..., "medio": ...}} sin duplicados.

    Primero usa la búsqueda de NOTICIAS (trae fecha y medio); si no da
    nada, prueba la búsqueda web normal (solo URL)."""
    all_links = {}
    print(f"[*] Fase 1: buscando enlaces relevantes (meta: ~{TARGET_COUNT} noticias)")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ddgs = DDGS()
        for query in query_list:
            print(f"    > Buscando: {query}", flush=True)
            nuevos = 0
            for tipo in ("news", "text"):
                try:
                    buscar = ddgs.news if tipo == "news" else ddgs.text
                    results = list(buscar(query, max_results=max_results_per_query) or [])
                except Exception as e:
                    print(f"      [!] Error ({tipo}): {type(e).__name__}: {str(e)[:100]}")
                    results = []
                for r in results:
                    href = r.get("url") or r.get("href")
                    if href and href not in all_links:
                        fecha = str(r.get("date") or "")[:10]
                        all_links[href] = {"fecha": fecha if re.match(r"\d{4}-\d{2}-\d{2}$", fecha) else "",
                                           "medio": r.get("source") or ""}
                        nuevos += 1
                if nuevos:
                    break          # si la búsqueda de noticias ha dado resultados, no hace falta la web
            print(f"      {nuevos} enlaces nuevos")
            time.sleep(2)          # pausa para que DuckDuckGo no nos bloquee
    print(f"[+] {len(all_links)} enlaces únicos encontrados\n")
    if not all_links:
        print("[!] 0 resultados en todas las búsquedas: DuckDuckGo nos está limitando o ha")
        print("    cambiado su API. Espera unos minutos o actualiza: pip install -U ddgs")
    return all_links


def extract_content(url: str):
    """Descarga una URL y, si el contenido es relevante, devuelve
    {'title', 'url', 'content'}. Si no es válida o falla, devuelve None."""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            res = requests.get(
                url, timeout=REQUEST_TIMEOUT, headers=HEADERS, verify=False
            )
        if res.status_code != 200:
            return None

        soup = BeautifulSoup(res.text, "html.parser")
        for tag in soup(NOISE_TAGS):
            tag.decompose()

        paras = [p.get_text().strip() for p in soup.find_all("p")]
        content = "\n\n".join(p for p in paras if p)
        title = soup.title.string.strip() if soup.title and soup.title.string else url

        content_norm = normalize_text(content)
        is_relevant = any(kw in content_norm for kw in KEYWORDS_FILTER)
        is_excluded = any(nk in content_norm for nk in NEGATIVE_KEYWORDS)

        if is_relevant and not is_excluded and len(content) > MIN_CONTENT_LENGTH:
            return {"title": title, "url": url, "content": content}
        return None
    except Exception:
        return None


def run_process():
    global OUTPUT_DIR, ZIP_NAME
    # Nunca borramos resultados anteriores: si la carpeta ya existe y tiene
    # ficheros, usamos una nueva con la fecha y la hora.
    if os.path.exists(OUTPUT_DIR) and os.listdir(OUTPUT_DIR):
        from datetime import datetime
        marca = datetime.now().strftime("%Y%m%d_%H%M%S")
        OUTPUT_DIR = f"{OUTPUT_DIR}_{marca}"
        ZIP_NAME = f"{OUTPUT_DIR}.zip"
        print(f"[i] La carpeta anterior ya tiene noticias: esta vez se guardan en {OUTPUT_DIR}/")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    all_links = search_links(QUERY_LIST, MAX_RESULTS_PER_QUERY)
    if not all_links:
        print("[!] No se encontraron enlaces. Revisa las queries o la conexión.")
        return

    print("[*] Fase 2: descargando y filtrando artículos...")
    count = 0
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_url = {executor.submit(extract_content, url): url for url in all_links}

        for future in as_completed(future_to_url):
            if count >= TARGET_COUNT:
                break
            try:
                news = future.result()
            except Exception:
                continue
            if not news:
                continue

            count += 1
            safe_title = safe_filename(news["title"])
            file_path = os.path.join(OUTPUT_DIR, f"{count}_{safe_title}.txt")
            with open(file_path, "w", encoding="utf-8") as f:
                meta = all_links.get(news["url"], {})
                f.write(f"# {news['title']}\n\nURL: {news['url']}\n"
                        f"Fecha: {meta.get('fecha', '')}\nMedio: {meta.get('medio', '')}\n\n"
                        f"{news['content']}")

            if count % 10 == 0 or count == 1:
                print(f"    [+] {count}/{TARGET_COUNT} noticias guardadas...")

    if count > 0:
        shutil.make_archive(ZIP_NAME.replace(".zip", ""), "zip", OUTPUT_DIR)
        print(f"\n[OK] Éxito: se han extraído {count} noticias.")
        print(f"[INFO] Artículos individuales en: ./{OUTPUT_DIR}/")
        print(f"[INFO] Archivo comprimido: ./{ZIP_NAME}")
    else:
        print("\n[!] No se encontró contenido suficiente. Prueba a ampliar QUERY_LIST,")
        print("    bajar MIN_CONTENT_LENGTH o revisar KEYWORDS_FILTER/NEGATIVE_KEYWORDS.")


if __name__ == "__main__":
    run_process()
