---
tipo: noticia
titular: "La policía pide el ADN de los turistas que estuvieron donde desapareció Madeleine"
medio: "El Mundo"
fecha: 2007-10-10
url: "https://www.elmundo.es/elmundo/2007/10/10/internacional/1192002028.html"
url_google: "https://news.google.com/rss/articles/CBMie0FVX3lxTE1iZGF1anRLeDVqTmRVRWgyODBzSDQ4djYzNmJKOW0xbkNNNGhsR0YyRWNHdkk5dWZKaUZ3WnZzSENjdFh3VUlvTnhxMnAxVnlSR3FnWENWaldiTHlfOHJ0MVRSV2tVRVk1NzQ4MnhaNzVxdWV4bE9rYWhhUQ?oc=5"
edicion: "España"
ventana: "2007-10"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2007-10-01 before:2007-11-01"
puntos: 1
motivo: "+ policía"
capturado: "2026-09-25T14:57:39"
tags: [noticia, mccann]
---

# La policía pide el ADN de los turistas que estuvieron donde desapareció Madeleine

> Texto del artículo pendiente de extraer con defuddle.
