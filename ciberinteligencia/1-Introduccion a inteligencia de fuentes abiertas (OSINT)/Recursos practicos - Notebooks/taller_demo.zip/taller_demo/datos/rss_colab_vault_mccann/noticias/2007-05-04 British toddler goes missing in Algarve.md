---
tipo: noticia
titular: "British toddler goes missing in Algarve"
medio: "The Guardian"
fecha: 2007-05-04
url: "https://www.theguardian.com/uk/2007/may/04/markoliver"
url_google: "https://news.google.com/rss/articles/CBMiY0FVX3lxTFB0NmxtcTdFNFdaUDNVd05aaFJaV2FCODN3bHZnV0lrV2JiQkhNRnJ2Ny0yRzVHOVV1S2kxV3EtaDIxMTBZcXVTamJDeEc2ak8zVDExblYtQ1QzbXZxcGsyejNsOA?oc=5"
edicion: "Reino Unido"
ventana: "2007-05"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2007-05-03 before:2007-06-01"
puntos: 1
motivo: "+ algarve"
capturado: "2026-09-25T14:56:59"
tags: [noticia, mccann]
---

# British toddler goes missing in Algarve

> Texto del artículo pendiente de extraer con defuddle.
