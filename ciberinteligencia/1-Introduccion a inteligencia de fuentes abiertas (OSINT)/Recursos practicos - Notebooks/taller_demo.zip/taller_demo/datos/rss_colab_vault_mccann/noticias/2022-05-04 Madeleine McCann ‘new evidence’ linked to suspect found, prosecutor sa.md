---
tipo: noticia
titular: "Madeleine McCann: ‘new evidence’ linked to suspect found, prosecutor says"
medio: "The Guardian"
fecha: 2022-05-04
url: "https://www.theguardian.com/uk-news/2022/may/04/some-new-evidence-found-against-madeleine-mccann-suspect-christian-bruckner"
url_google: "https://news.google.com/rss/articles/CBMiwAFBVV95cUxORHVmNHRtUmI4V1lJSi1fYUtrWThqN1E4T3luX0c5N1hldFBHNnNDaExJOWZCb2QxbUJqSG9GVm1DNnJuWG9Ocll0ZlNEUmctRlNtNFpBZ3hucmVab2hHeDZMTUJOLWp5b1hzZEtiSXFVeXpLNzRqY0hFTm5KeHRhVUFzQm9QLVlKaWd3aWJCWWhQZzl2SHBWcHh2LTczSHRoRGt5S09XQklNSk9PVUM4TnZacFVQamV4UWRDa0w2SXM?oc=5"
edicion: "Reino Unido"
ventana: "2022"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2022-01-01 before:2023-01-01"
puntos: 3
motivo: "+ prosecutor, suspect, evidence"
capturado: "2026-09-25T15:00:14"
tags: [noticia, mccann]
---

# Madeleine McCann: ‘new evidence’ linked to suspect found, prosecutor says

> Texto del artículo pendiente de extraer con defuddle.
