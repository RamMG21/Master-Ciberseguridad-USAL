# Vault del caso Madeleine McCann · Taller de Ciberinteligencia (USAL)

Este vault es un ejercicio docente de OSINT. Contiene noticias publicadas sobre el caso y las entidades que aparecen en ellas. Usa las skills de Obsidian instaladas en `.claude/skills/` (obsidian-markdown, json-canvas, obsidian-bases, defuddle) cuando corresponda.

## Estructura

| Carpeta | Contenido |
|---|---|
| `noticias/` | Una nota por noticia. **Son las fuentes: no inventes nada que no esté en ellas.** Propiedad `origen`: `rss` (Google News) o `duckduckgo` (script de búsqueda) |
| `entidades/personas/` | Una nota por persona |
| `entidades/lugares/` | Una nota por lugar (país, ciudad, localidad, edificio, zona de búsqueda) |
| `entidades/organizaciones/` | Una nota por organización (policías, fiscalías, tribunales, medios, fundaciones) |
| `entidades/eventos/` | Una nota por hecho fechado (desaparición, registro, declaración, juicio…) |
| `MOC - Caso McCann.md` | Mapa de contenido: la puerta de entrada al vault |

## Reglas para crear notas de entidad

1. **Solo a partir de las noticias.** Cada afirmación de una nota de entidad debe ir seguida del enlace a la noticia que la sostiene: `… fue interrogado en 2007 ([[2007-09-07 Titular de la noticia]]).` Si no hay fuente, no se escribe.
2. **Nombre de fichero** = nombre más usado en las fuentes, sin tildes raras ni caracteres prohibidos (`/ \ : * ? " < > | # ^ [ ]`). Personas: `Nombre Apellido`. Lugares: nombre local (`Praia da Luz`).
2b. **Mismo nombre para el mismo sitio en todas las notas:** si el lugar es `Braunschweig`, la organización es `Fiscalía de Braunschweig`, no «de Brunswick». Las variantes en otros idiomas van en `alias`.
3. **Antes de crear, busca si ya existe** (también por sus alias). Si existe, añade la nueva fuente y la nueva información; no dupliques.
4. **Propiedades** (frontmatter YAML) de cada entidad:
   ```yaml
   ---
   tipo: persona          # persona | lugar | organizacion | evento
   alias: []              # otras formas en que la nombran las fuentes (Maddie, Madeleine…)
   rol: ""                # una línea: qué papel tiene en el caso según las fuentes
   pais: ""               # si aplica
   fecha: ""              # solo eventos: AAAA-MM-DD (o AAAA-MM si no hay día)
   primera_mencion: ""    # fecha de la noticia más antigua que la menciona
   fuentes: []            # lista de enlaces a noticias: ["[[2007-05-04 …]]", "[[2020-06-04 …]]"]
   n_fuentes: 0
   tags: [entidad]
   ---
   ```
5. **Cuerpo** de la nota: un resumen de 2 a 5 frases, cada una con su fuente, y una sección `## Relaciones` con enlaces a otras entidades y el porqué (`- [[Portimão]]: sede de la policía que investigó al principio ([[fuente]])`).
5b. **Quién actúa.** En las notas de **evento**, la sección `## Relaciones` debe decir quién lo **ejecutó o protagonizó** (la organización o persona que investigó, registró, interrogó, detuvo, declaró arguido, archivó o juzgó), si la noticia lo dice: `- [[Polícia Judiciária]]: declaró arguido a [[Robert Murat]] ([[noticia]])`. Un evento no es un actor: no escribas «el nombramiento registró su casa».
6. **Lenguaje prudente.** Son personas reales. Usa las palabras de las fuentes: «sospechoso», «investigado», «acusado», «condenado» no son sinónimos. No atribuyas culpas que las fuentes no afirman. Si dos fuentes se contradicen, recoge las dos versiones con su enlace y márcalo con un callout `> [!warning] Contradicción`.
7. **Ignora** a periodistas firmantes, personas citadas solo de pasada y lugares genéricos («Europa», «el mundo») salvo que tengan un papel en los hechos.

## Reglas para las notas de noticia

- No cambies el texto del artículo ni las propiedades existentes.
- Si una noticia tiene `texto: fallo`, solo tienes su titular (el medio no dejó descargar el artículo): extrae únicamente lo que diga el titular y no completes con lo que sepas del caso.
- Al procesar una noticia, añade al final una sección `## Entidades` con los enlaces a todas las entidades que has extraído de ella, agrupadas por tipo. Esa sección es la que construye el grafo.

## Idioma

Las notas nuevas, en español. Los nombres propios, como aparecen en las fuentes.
