---
tipo: noticia
titular: "La Fiscalía alemana cree que Madeleine McCann está muerta y abre una investigación por asesinato contra el sospechoso"
medio: "RTVE.es"
fecha: 2020-06-04
url: "https://www.rtve.es/noticias/20200604/fiscalia-aleman-cree-madeleine-mccann-esta-muerta-abre-investigacion-por-asesinato-contra-sospechoso/2015600.shtml"
url_google: "https://news.google.com/rss/articles/CBMi5wFBVV95cUxPTENWQTZGTUdPcVdBbmJjajY3X2lUbUltRGFVVlBfR2M4SkFSM2xsTFNtWHdhdGNLZE0yZGpJNmRoWGhWTDFYTUZ5TEFzQlZuN3BzRkxEclk5RDBsUUtvQjhOcXFkcDVBNTFzTHFMVFJTdTRhME5PdTRrdFdHS1ZEYjY0TmxDVzlMTTVCNEVOR2ZPVUlxVl9aWTZaeFRxRUw1VExJUzd1Y21HU0kwb0JWaUFKOXhCSHRFTUNTVlVqM0I3WUZLdVdfUWZSZFNkTEpVbjlTbjZnbndoUWhmUEtncVExNDRZOGc?oc=5"
edicion: "España"
ventana: "2020"
busqueda: "\"Madeleine McCann\" OR \"Maddie McCann\" after:2020-01-01 before:2021-01-01"
puntos: 3
motivo: "+ fiscalía, investigación, sospechoso"
capturado: "2026-09-25T15:00:02"
tags: [noticia, mccann]
---

# La Fiscalía alemana cree que Madeleine McCann está muerta y abre una investigación por asesinato contra el sospechoso

> Texto del artículo pendiente de extraer con defuddle.
