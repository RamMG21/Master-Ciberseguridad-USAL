# Demo 1 · Obsidian con un ejemplo sencillo: una familia

**Taller OSINT · Obsidian · unos 12 minutos**

Antes de meter 130 noticias en Obsidian, vamos a hacer a mano, con cuatro personas, **exactamente lo mismo que después hará la IA**: una nota por persona, lugar y evento; enlaces entre ellas; unas propiedades arriba; y una sección de relaciones. Al final lo veremos como grafo y como mapa de vínculos.

> **La familia es inventada.** Si la haces con la tuya, ten en cuenta que estarás creando justo el tipo de fichas que luego discutiremos en la parte de ética.

| Paso | Qué aprendes | Min |
|---|---|---|
| 1 | Qué es un vault | 1 |
| 2 | Carpetas: la misma estructura que el caso | 1 |
| 3 | Notas y enlaces `[[ ]]` | 2 |
| 4 | Crear notas desde un enlace y backlinks | 2 |
| 5 | Propiedades y alias | 2 |
| 6 | Un evento que lo une todo | 1 |
| 7 | El grafo | 2 |
| 8 | Del grafo al mapa de vínculos (Canvas) | 2 |
| 9 | Renombrar sin romper nada | 0,5 |

**Atajos:** en Windows y Linux, `Ctrl` donde pone `Cmd`.

---

## Paso 1 · Crear el vault

Obsidian → **Crear bóveda nueva** → nombre `demo_familia` → elige dónde guardarla (por ejemplo, el Escritorio) → **Crear**.

Abre esa carpeta en el Finder o el Explorador: está **vacía**, salvo una carpeta oculta `.obsidian` con la configuración.

**La idea:** un vault es **una carpeta de ficheros de texto**. Cada nota será un fichero `.md` que puedes abrir con cualquier editor. Nada se sube a ninguna nube si no quieres.

---

## Paso 2 · Crear las carpetas

En el panel de la izquierda, botón **Nueva carpeta** (icono de carpeta con +), tres veces:

```
personas
lugares
eventos
```

**La idea:** es la misma estructura que tendrá el vault del caso McCann, más `organizaciones`. Una carpeta por tipo de entidad.

---

## Paso 3 · La primera nota y sus enlaces

Clic derecho en `personas` → **Nueva nota** → título `Elena Martín`. Pega:

```markdown
Enfermera. Vive en [[Salamanca]] con su marido, [[Javier Ruiz]].
Su hija [[Lucía Ruiz]] estudia en [[Madrid]].
Su padre, [[Tomás Martín]], vive en [[Candelario]].
```

**Qué observar:** los nombres entre **dobles corchetes** salen en otro color. Son **enlaces a otras notas**, aunque **todavía no existan**. Obsidian te deja apuntar a cosas antes de escribirlas.

---

## Paso 4 · Crear notas desde el enlace y ver los backlinks

`Cmd + clic` sobre `[[Javier Ruiz]]` → se crea la nota. Muévela a `personas` (arrástrala). Pega:

```markdown
Profesor de instituto. Casado con [[Elena Martín]].
Los domingos sube a [[Candelario]] a ver a su suegro.
```

Haz lo mismo con `[[Tomás Martín]]` (a `personas`):

```markdown
Jubilado. Vive en [[Candelario]].
```

Y con `[[Lucía Ruiz]]` (a `personas`):

```markdown
Estudiante de Periodismo en [[Madrid]].
```

Ahora abre `Tomás Martín` y, en el panel derecho, mira **Menciones enlazadas** (*backlinks*).

**Qué observar:** en la nota de Tomás aparecen **Elena** y **Javier**, aunque en su nota no los hayas enlazado. Cada nota sabe quién la menciona. Es la pregunta de siempre del analista: *¿dónde más aparece esta persona?*

> Si no ves el panel derecho: botón de la esquina superior derecha, o `Cmd + P` y escribe «menciones».

---

## Paso 5 · Propiedades y alias

Abre `Javier Ruiz`, selecciona todo su texto (`Cmd + A`) y **sustitúyelo** por esto. Al pegar, Obsidian convierte el bloque entre `---` en una tabla de **propiedades**:

```markdown
---
tipo: persona
alias: [Javi]
rol: "Marido de Elena, padre de Lucía"
fuentes: []
tags: [entidad]
---
Profesor de instituto. Casado con [[Elena Martín]].
Los domingos sube a [[Candelario]] a ver a su suegro.
```

Ahora ve a la nota de Lucía y escribe `[[Javi`. Obsidian te propone **Javier Ruiz**.

**Qué observar:**
- Las **propiedades** son campos (tipo, rol, fuentes…) dentro de una nota de texto. Luego se pueden **filtrar como una tabla**.
- El **alias** resuelve un problema de siempre en OSINT: la misma entidad con nombres distintos. En el caso McCann, *Maddie* y *Madeleine*, o *PJ* y *Polícia Judiciária*.
- Es **la misma plantilla** que usará la IA para cada persona del caso.

---

## Paso 6 · Un evento que lo une todo

En `eventos`, nota nueva `Comida de Navidad 2025`. Pega:

```markdown
---
tipo: evento
fecha: 2025-12-25
---
Comida familiar en casa de [[Tomás Martín]], en [[Candelario]].
Asistieron [[Elena Martín]], [[Javier Ruiz]] y [[Lucía Ruiz]].
```

**La idea:** los eventos conectan a varias personas con un lugar y una fecha. Fíjate en esto porque volverá a salir: **un evento al que va todo el mundo se convierte en el nodo más gordo del grafo**. En el caso McCann pasa con «la desaparición».

---

## Paso 7 · El grafo

Abre la **vista de grafo**: `Cmd + G` o el icono de la barra izquierda.

1. **Colores por tipo:** ajustes del grafo (rueda dentada) → **Grupos** → *Nuevo grupo*:
   - `path:personas` → azul
   - `path:lugares` → verde
   - `path:eventos` → rojo
2. **Grafo local:** abre la nota de `Tomás Martín` → menú `⋯` → **Abrir grafo local**. Solo se ve su entorno.
3. **Filtro:** en los ajustes del grafo, en *Buscar archivos*, escribe `path:personas`. Solo quedan las personas y los enlaces entre ellas.

**Qué observar:**
- **No hemos dibujado nada.** El grafo sale solo de los `[[ ]]`: cada nota es un punto y cada enlace, una línea.
- Las **líneas no dicen qué relación hay**: la de Elena con Javier es igual que la de Javier con Candelario. Para eso está el paso siguiente.

---

## Paso 8 · Del grafo al mapa de vínculos (Canvas)

Primero, escribe las relaciones con su **tipo**, igual que hará la IA. Al final de la nota de `Elena Martín`, añade:

```markdown
## Relaciones
- [[Javier Ruiz]]: su marido
- [[Lucía Ruiz]]: su hija
- [[Tomás Martín]]: su padre
- [[Salamanca]]: donde vive
```

Ahora el mapa:
1. Botón **Nuevo lienzo** (Canvas) en la barra izquierda, o `Cmd + P` → «Crear nuevo lienzo». Llámalo `Mapa familia`.
2. **Arrastra** desde el panel izquierdo las notas de Elena, Javier, Lucía y Tomás al lienzo.
3. Pasa el ratón por el borde de la tarjeta de Elena, **arrastra desde el punto** hasta Javier: se crea una flecha.
4. **Doble clic en la flecha** (o clic derecho → *Editar etiqueta*) y escribe: `su marido`. Repite con `su hija` y `su padre`.
5. Colorea: clic derecho en una tarjeta → color.

**Qué observar:** esto es un **mapa de vínculos** (un *link chart*, como los que hacen las policías): cada flecha tiene **dirección** y **tipo de relación**. El grafo te dice *que* hay relación; el mapa te dice *cuál*. Más adelante, la IA hará este mismo mapa para una persona del caso.

---

## Paso 9 · Renombrar sin romper nada

Renombra `Salamanca` a `Salamanca (ciudad)`: clic en el título de la nota y escribe. Vuelve a la nota de Elena.

**Qué observar:** el enlace se ha **actualizado solo**. Cuando la IA fusione duplicados («Maddie» y «Madeleine McCann»), Obsidian hará lo mismo con todos los enlaces.

---

## Lo que tienes que llevarte

| Pieza | En la familia | En el caso McCann |
|---|---|---|
| Nota | `Elena Martín.md` | Una nota por noticia y por entidad |
| Enlace | `[[Javier Ruiz]]` | La noticia enlaza a sus entidades |
| Backlinks | Quién menciona a Tomás | En qué noticias aparece una persona |
| Propiedades | `tipo`, `alias`, `rol` | Las mismas, más `fuentes` y `n_fuentes` |
| Grafo | 8 notas | Unas 290 notas |
| Mapa de vínculos | 4 tarjetas y 3 flechas | La red de una persona del caso |

La diferencia es que en el caso **no lo escribimos a mano**: lo hace una IA siguiendo unas reglas. Y la regla más importante es una que aquí no hemos necesitado: **cada afirmación tiene que decir de qué noticia sale.**

**Siguiente:** volvemos a las diapositivas, al caso McCann.

---

## Chuleta de atajos

| Acción | macOS | Windows / Linux |
|---|---|---|
| Nota nueva | `Cmd + N` | `Ctrl + N` |
| Abrir o crear nota desde un enlace | `Cmd + clic` | `Ctrl + clic` |
| Buscar notas por nombre | `Cmd + O` | `Ctrl + O` |
| Buscar en todo el vault | `Cmd + Mayús + F` | `Ctrl + Mayús + F` |
| Vista de grafo | `Cmd + G` | `Ctrl + G` |
| Paleta de comandos | `Cmd + P` | `Ctrl + P` |
| Alternar edición y lectura | `Cmd + E` | `Ctrl + E` |
